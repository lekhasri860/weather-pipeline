import sqlite3

def fix_coordinates():
    conn = sqlite3.connect('database/weather_data.db')
    cursor = conn.cursor()

    updates = {
        "Delhi":     (28.6139, 77.2090),
        "Kolkata":   (22.5726, 88.3639),
        "Mumbai":    (19.0760, 72.8777)
    }

    for city, (lat, lon) in updates.items():
        cursor.execute("""
            UPDATE cities 
            SET latitude = ?, longitude = ? 
            WHERE city_name = ?
        """, (lat, lon, city))
        print(f"✅ Updated coordinates for {city}: ({lat}, {lon})")

    conn.commit()
    conn.close()
    print("🎉 All coordinates fixed!")

if __name__ == "__main__":
    fix_coordinates()