import sys
import os

# Important: Add current project root to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database import setup_database
from etl_pipeline import run_etl
from reporter import generate_report

os.makedirs('logs', exist_ok=True)
os.makedirs('reports', exist_ok=True)

if __name__ == "__main__":
    if len(sys.argv) > 1:
        action = sys.argv[1]
        
        if action == "setup":
            setup_database()
            print("✅ Database setup completed!")
            
        elif action == "run":
            print("🔄 Running full weather pipeline...")
            setup_database()
            run_etl()
            generate_report()
            
        elif action == "report":
            generate_report()
            
        else:
            print("Usage: python src/main.py [setup | run | report]")
    else:
        print("Usage: python src/main.py [setup | run | report]")