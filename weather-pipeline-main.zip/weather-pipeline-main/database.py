import sqlite3
import os

DB_PATH = "database/weather_data.db"

def setup_database():
    os.makedirs("database", exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute('''CREATE TABLE IF NOT EXISTS cities (
                        city_id INTEGER PRIMARY KEY,
                        city_name TEXT NOT NULL UNIQUE,
                        country TEXT,
                        latitude REAL,
                        longitude REAL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )''')
    
    cursor.execute('''CREATE TABLE IF NOT EXISTS weather_data (
                        record_id INTEGER PRIMARY KEY,
                        city_id INTEGER,
                        timestamp TIMESTAMP,
                        temperature_c REAL,
                        humidity INTEGER,
                        pressure_hpa REAL,
                        wind_speed_mps REAL,
                        weather_condition TEXT,
                        rain_mm REAL DEFAULT 0,
                        FOREIGN KEY (city_id) REFERENCES cities (city_id)
                    )''')
    
    conn.commit()
    conn.close()
    print("✅ Database ready!")


def get_or_create_city(city_name, country="IN", latitude=None, longitude=None):
    """Get existing city or create new one with coordinates"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Check if city already exists
    cursor.execute("SELECT city_id FROM cities WHERE city_name = ?", (city_name,))
    row = cursor.fetchone()
    
    if row:
        conn.close()
        return row[0]
    
    # Insert new city with latitude and longitude
    cursor.execute("""INSERT INTO cities 
                      (city_name, country, latitude, longitude) 
                      VALUES (?, ?, ?, ?)""", 
                   (city_name, country, latitude, longitude))
    
    conn.commit()
    city_id = cursor.lastrowid
    conn.close()
    print(f"🆕 Added new city: {city_name} ({latitude}, {longitude})")
    return city_id