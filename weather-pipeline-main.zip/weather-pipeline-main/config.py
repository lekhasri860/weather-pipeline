# ==================== CONFIG ====================
# ←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←
# REPLACE THIS WITH YOUR REAL API KEY
API_KEY = "abcd1234efgh5678ijkl9012mnop3456"

# Cities we will track (including your city Hyderabad)
CITIES = [
    "Mumbai,IN",
    "Delhi,IN",
    "Bangalore,IN",
    "Chennai,IN",
    "Kolkata,IN",
    "Hyderabad,IN"
]

# Alert thresholds
TEMP_HIGH_THRESHOLD = 30.0
HUMIDITY_HIGH_THRESHOLD = 75

# Other settings
DB_PATH = "database/weather_data.db"
# ===============================================