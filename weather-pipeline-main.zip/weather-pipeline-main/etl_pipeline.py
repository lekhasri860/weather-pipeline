import sqlite3
import sys
import os

# Add project root to Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Hardcoded config
CITIES = [
    "Mumbai,IN",
    "Delhi,IN",
    "Bangalore,IN",
    "Chennai,IN",
    "Kolkata,IN",
    "Hyderabad,IN"
]

TEMP_HIGH_THRESHOLD = 30.0
HUMIDITY_HIGH_THRESHOLD = 75

from api_client import fetch_weather_data
from database import get_or_create_city

def run_etl():
    print("🚀 Starting Weather ETL Pipeline...\n")
    
    records_processed = 0
    
    for city_str in CITIES:
        print(f"🌍 Fetching weather for {city_str}...")
        raw_data = fetch_weather_data(city_str)
        
        if not raw_data:
            print(f"❌ Failed to fetch data for {city_str}")
            continue
        
        city_name = raw_data['city']
        country = city_str.split(',')[1] if ',' in city_str else 'IN'
        
        # Fixed call - now passing latitude and longitude
        city_id = get_or_create_city(
            city_name, 
            country, 
            raw_data['latitude'], 
            raw_data['longitude']
        )
        
        # Save to database
        conn = sqlite3.connect('database/weather_data.db')
        cursor = conn.cursor()
        cursor.execute("""INSERT INTO weather_data 
                          (city_id, timestamp, temperature_c, humidity, pressure_hpa, 
                           wind_speed_mps, weather_condition, rain_mm)
                          VALUES (?,?,?,?,?,?,?,?)""",
                       (city_id, raw_data['timestamp'], raw_data['temperature'], 
                        raw_data['humidity'], raw_data['pressure'], raw_data['wind_speed'],
                        raw_data.get('condition', 'Unknown'), raw_data.get('rain_mm', 0.0)))
        conn.commit()
        conn.close()
        
        records_processed += 1
        condition = raw_data.get('condition', 'Unknown').capitalize()
        print(f"✅ Saved: {city_name} → {raw_data['temperature']}°C, {raw_data['humidity']}% , {condition}\n")
        
        # Alerts
        if raw_data['temperature'] > TEMP_HIGH_THRESHOLD:
            print(f"⚠️ High Temperature Alert: {city_name} ({raw_data['temperature']}°C)")
        if raw_data['humidity'] > HUMIDITY_HIGH_THRESHOLD:
            print(f"⚠️ High Humidity Alert: {city_name} ({raw_data['humidity']}%)\n")
    
    print(f"🎉 ETL Completed! Processed {records_processed} cities")
    return records_processed