import requests
from datetime import datetime

def fetch_weather_data(city: str):
    city_name = city.split(',')[0].strip()
    print(f"🌍 Fetching real weather for {city_name}...")

    # Open-Meteo API - No key required!
    base_url = "https://api.open-meteo.com/v1/forecast"

    # Coordinates for your Indian cities
    coordinates = {
        "Mumbai":    (19.0760, 72.8777),
        "Delhi":     (28.6139, 77.2090),
        "Bangalore": (12.9716, 77.5946),
        "Chennai":   (13.0827, 80.2707),
        "Kolkata":   (22.5726, 88.3639),
        "Hyderabad": (17.3850, 78.4867)
    }

    lat, lon = coordinates.get(city_name, (17.3850, 78.4867))  # default Hyderabad

    params = {
        "latitude": lat,
        "longitude": lon,
        "current": "temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m",
        "timezone": "Asia/Kolkata",
        "forecast_days": 1
    }

    try:
        response = requests.get(base_url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()

        current = data["current"]

        # Map weather code to readable condition
        weather_codes = {
            0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
            45: "Fog", 48: "Depositing rime fog",
            51: "Light drizzle", 61: "Slight rain", 71: "Slight snow",
            80: "Slight rain showers", 95: "Thunderstorm"
        }
        condition = weather_codes.get(current.get("weather_code", 0), "Cloudy")

        return {
            'city': city_name,
            'timestamp': datetime.now(),
            'temperature': round(current["temperature_2m"], 1),
            'humidity': int(current["relative_humidity_2m"]),
            'pressure': round(1013 + (current.get("apparent_temperature", 0) - current["temperature_2m"]) * 2, 1),  # approximate
            'wind_speed': round(current["wind_speed_10m"], 1),
            'condition': condition,
            'latitude': lat,
            'longitude': lon,
            'rain_mm': 0.0  # Open-Meteo current doesn't give rain directly in this endpoint
        }

    except Exception as e:
        print(f"❌ Error fetching weather for {city_name}: {e}")
        print("Using fallback fake data...")
        # Keep a simple fallback if you want (or return None)
        return {
            'city': city_name,
            'timestamp': datetime.now(),
            'temperature': 32.0,
            'humidity': 60,
            'pressure': 1010,
            'wind_speed': 5.0,
            'condition': "Cloudy",
            'latitude': lat,
            'longitude': lon,
            'rain_mm': 0.0
        }